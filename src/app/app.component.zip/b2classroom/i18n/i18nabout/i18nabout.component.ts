import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-i18nabout',
  templateUrl: './i18nabout.component.html',
  styleUrls: ['./i18nabout.component.css']
})
export class I18naboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
