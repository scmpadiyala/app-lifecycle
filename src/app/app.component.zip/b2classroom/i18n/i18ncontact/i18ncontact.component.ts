import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-i18ncontact',
  templateUrl: './i18ncontact.component.html',
  styleUrls: ['./i18ncontact.component.css']
})
export class I18ncontactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
