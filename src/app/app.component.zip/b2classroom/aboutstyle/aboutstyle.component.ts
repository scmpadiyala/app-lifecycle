import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutstyle',
  templateUrl: './aboutstyle.component.html',
  styles: ["div {background-color: yellow;}"]
})
export class AboutstyleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
