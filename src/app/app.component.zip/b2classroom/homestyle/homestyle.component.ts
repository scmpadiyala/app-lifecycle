import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homestyle',
  templateUrl: './homestyle.component.html',
  styleUrls: ['./homestyle.component.css']
})
export class HomestyleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
