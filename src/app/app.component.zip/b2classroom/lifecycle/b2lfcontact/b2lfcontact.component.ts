import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b2lfcontact',
  templateUrl: './b2lfcontact.component.html',
  styleUrls: ['./b2lfcontact.component.css']
})
export class B2lfcontactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
